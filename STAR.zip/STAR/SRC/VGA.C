/*
 *	File: VGA.C
 *
 *	Functions common to all VGA drivers, including modesetting, vertical
 *	blank synchronization, and palette modification.
 *
 *  Copyright (c) 2025 by Will Klees
 */

#include <CONIO.H>
#include <DOS.H>
#include <I86.H>

void vga_setmode(unsigned char mode) {
    union REGS regs;
    regs.x.eax = mode;
    int386(0x10, &regs, &regs);
}

void vga_waitblank() {
    while ((inp(0x03DA) & 8));
    while (!(inp(0x3DA) & 8));
}

void vga_setpal(unsigned char idx, unsigned char r, unsigned char g, unsigned char b) {
    outp(0x3c8, idx);
    outp(0x3c9, r >> 2);
    outp(0x3c9, g >> 2);
    outp(0x3c9, b >> 2);
}
