/*
 *	File: MODEX.C
 *
 *	Code to set up basic Mode X VGA display.
 *
 *  Copyright (c) 2025 by Will Klees
 */

