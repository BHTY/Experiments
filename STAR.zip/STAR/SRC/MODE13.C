/*
 *	File: MODE13.C
 *
 *	Code to set up basic Mode 13h MCGA/VGA display.
 *
 *  Copyright (c) 2025 by Will Klees
 */

#include "VGA.H"
#include "SURFACE.H"
#include "FRAMEBUF.H"
#include <stdlib.h>
#include <string.h>

#define VGA_FBPTR   ((unsigned char*)0xA0000L)
#define VGA_XRES    320
#define VGA_YRES    200

SURFACE RenderTarget;
u8* backBuffer;

void mode13_SwapBuffers() {
    u16 lines = RenderTarget.Height;
    u8* src = backBuffer;
    u8* dst = VGA_FBPTR + (((VGA_YRES-RenderTarget.Height)>>1)*VGA_XRES) + ((VGA_XRES-RenderTarget.Width)>>1);

    while (lines--) {
        memcpy(dst, src, RenderTarget.Width);
        src += RenderTarget.Pitch;
        dst += VGA_XRES;
    }
}

void vid_dimensions(u16 x, u16 y) {
    RenderTarget.Width = x;
    RenderTarget.Height = y;
    RenderTarget.Pitch = x;

    /* Fill front buffer with blue */
    memset(VGA_FBPTR, 1, VGA_XRES*VGA_YRES);
}

void vid_init() {
    vga_setmode(0x13);
    backBuffer = malloc(320*200);
    RenderTarget.FillScreen = fb_FillScreen;
    RenderTarget.SwapBuffers = mode13_SwapBuffers;
    RenderTarget.PlotPixel = fb_PlotPixel;
    RenderTarget.DrawLine = fb_DrawLine;
    RenderTarget.FillTri = fb_FillTri;
    vid_dimensions(320, 200);
}
