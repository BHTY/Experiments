/*
 *	File: DRAW3D.C
 *
 *	Basic 3D object drawing engine using the renderer.
 *
 *	Copyright (c) 2025 by Will Klees
 */

#include "DRAW3D.H"
#include "SURFACE.H"

TRANSFORM   ViewMatrix;

/* */
void    model_matrix(ENTITY* ent, TRANSFORM* xform) {
    quat_tomat3(&(ent->ori), xform->rot);
    xform->trans = ent->pos;
}

/* */
void    view_matrix(VEC3* cam_pos, QUAT* cam_ori) {
    TRANSFORM ori_xform, xlate_xform;
    mat3_identity(xlate_xform.rot);
    xlate_xform.trans.x = -cam_pos->x;
    xlate_xform.trans.y = -cam_pos->y;
    xlate_xform.trans.z = -cam_pos->z;
    quat_tomat3(cam_ori, ori_xform.rot);
    ori_xform.trans.x = 0;
    ori_xform.trans.y = 0;
    ori_xform.trans.z = 0;
    xform_mul(&ori_xform, &xlate_xform, &ViewMatrix);
}

/* */
void draw_entity(ENTITY* ent) {
    TRANSFORM model_xform;
    int i;
    u32 vert_offset = gfxVertexIndex;

    model_matrix(ent, &model_xform);
    xform_mul(&ViewMatrix, &model_xform, &gfxModelView);

    for (i = 0; i < ent->mesh.nverts; i++) {
        gfx_vertex(&(ent->mesh.verts[i]));
    }

    for (i = 0; i < ent->mesh.npolys; i++) {
        GFX_POLY* poly = &(ent->mesh.polys[i]);
        gfx_submit_tri(
            poly->i0 + vert_offset, 
            poly->i1 + vert_offset, 
            poly->i2 + vert_offset,
            0 ? 0 : poly->color
        );
    }
}

/* */
void    draw_prism(FIXED centerx, FIXED centery, FIXED centerz, FIXED lengthx, FIXED lengthy, FIXED lengthz, u8 color) {

}

/* */
void    draw_line3d(FIXED x1, FIXED y1, FIXED z1, FIXED x2, FIXED y2, FIXED z2, u8 color) {
    VEC3 v1, v2;
    GFX_VERT gv1, gv2;

    v1.x = x1;
    v1.y = y1;
    v1.z = z1;

    v2.x = x2;
    v2.y = y2;
    v2.z = z2;

    if (gfx_xform(&v1, &gv1) && gfx_xform(&v2, &gv2)) {
        RT_DrawLine(gv1.ssx, gv1.ssy, gv2.ssx, gv2.ssy, color);
    }
}

/* */
void    draw_point3d(FIXED x, FIXED y, FIXED z, u8 color) {
    VEC3 v;
    GFX_VERT gv;

    v.x = x;
    v.y = y;
    v.z = z;

    if (gfx_xform(&v, &gv)) {
        RT_PlotPixel(gv.ssx, gv.ssy, color);
    }
}


