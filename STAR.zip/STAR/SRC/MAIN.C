/*
 *	File: MAIN.C
 *
 *	Test program for SLIPSTREAM renderer.
 *
 *	Copyright (c) 2025 by Will Klees
 */

#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include "vga.h"
#include "surface.h"
#include "draw3d.h"

int opt_vsync = 1;
unsigned long nframes = 0;
volatile unsigned long nticks = 0;
static void interrupt (*prev_timer_intr)();

#define ARRAYSIZEOF(a)  (sizeof(a)/sizeof(a[0]))

GFX_POLY cube_faces[12]= {
    {0, 1, 2, 1}, /* Side 1 */
    {2, 1, 3, 1}, 
    {4, 0, 6, 2}, /* Side 2 */
    {6, 0, 2, 2}, 
    {7, 5, 6, 3}, /* Side 3 */
    {6, 5, 4, 3}, 
    {3, 1, 7, 4}, /* Side 4 */
    {7, 1, 5, 4},
    {4, 5, 0, 5}, /* Side 5 */
    {0, 5, 1, 5},
    {3, 7, 2, 6}, /* Side 6 */
    {2, 7, 6, 6}
};

VEC3 cube_verts[8] = {{ITOFIX(-3), ITOFIX(3), ITOFIX(-3)},
    {ITOFIX(3), ITOFIX(3), ITOFIX(-3)},
    {ITOFIX(-3), ITOFIX(-3), ITOFIX(-3)},
    {ITOFIX(3), ITOFIX(-3), ITOFIX(-3)},
    {ITOFIX(-3), ITOFIX(3), ITOFIX(3)},
    {ITOFIX(3), ITOFIX(3), ITOFIX(3)},
    {ITOFIX(-3), ITOFIX(-3), ITOFIX(3)},
    {ITOFIX(3), ITOFIX(-3), ITOFIX(3)}};

GFX_MESH cube_mesh = {ARRAYSIZEOF(cube_verts), ARRAYSIZEOF(cube_faces), cube_verts, cube_faces};

ENTITY cube;

VEC3 CameraPosition;
QUAT CameraOrientation;

void interrupt timer_intr()
{
	nticks++;
	_chain_intr(prev_timer_intr);
}

void update() {
    quat_create(nframes*96, nframes*96, 0, &(cube.ori));
}

/* We store verts in viewspace and screenspace after xforms */
/* We transform lightdir to viewspace by multiplying with rotation component of view matrix */
/* Our LUT for Z is based on the viewport */

void draw_scene() {
    gfx_clear();
    draw_entity(&cube);
    gfx_present();
}

void draw_frame() {
    /* Draw 3D elements */
    quat_conjugate(&CameraOrientation, &CameraOrientation);

    view_matrix(&CameraPosition, &CameraOrientation);
    draw_scene();
    quat_conjugate(&CameraOrientation, &CameraOrientation);

    /* Copy to front and fill back buffer with background color */
    RT_SwapBuffers();
    RT_FillScreen(0);
}

void init_palette() {
	int i, n, p;
	unsigned char r, g, b;

	for (i = 0; i < 16; i++){ //color (RGBI)
		r = (i & 4) ? ((i & 8) ? 16 : 8) : 0;
		g = (i & 2) ? ((i & 8) ? 16 : 8) : 0;
		b = (i & 1) ? ((i & 8) ? 16 : 8) : 0;

		//reserve a few colors for special use that do not comply with the RGBI system
		if (i == 7){
			r = 16;
			g = 8;
			b = 0;
		}

		for (p = 0; p < 16; p++){ //intensity
			vga_setpal(16 * i + p, r * p, g * p, b * p);

            if (16*i+p == 15 || 16*i+p == 7 || 16*i+p == 8) {
                vga_setpal(16*i+p,255,255,255);
            }
		}
	}
}

int main(int argc, char** argv) { 
	unsigned long rate, total_ticks, sec;

    vid_init();
    init_palette();

    /* Init cube entity */
    cube.pos.x = 0;
    cube.pos.y = 0;
    cube.pos.z = 0xC0000;
    cube.mesh = cube_mesh;

    /* Init position and orientation */
    quat_create(0, 0, 0, &CameraOrientation);
    CameraPosition.x = 0;//-0x40000;
    CameraPosition.y = 0;//-0x10000;
    CameraPosition.z = 0;

    gfx_zclip(0x10000, 0x10000000);
    gfx_viewport(320, 200);

	prev_timer_intr = _dos_getvect(0x1c);
	_dos_setvect(0x1c, timer_intr);

    while (!kbhit()) {
        update();
        draw_frame();
        if (opt_vsync) vga_waitblank();
        nframes++;
    }

    total_ticks = nticks;
    _dos_setvect(0x1c, prev_timer_intr);

    vga_setmode(0x03);

    /* 1.193182MHz / 65536 = 18.20651245117 ticks/sec */
	rate = nframes * 1820 / nticks;
	sec = nticks * 100 / 182;
	printf("%lu frames in %lu.%lu sec - %lu.%lu fps\n", nframes,
			sec / 10, sec % 10, rate / 100, rate % 100);

    return 0;
}
