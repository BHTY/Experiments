/*
 *	File: FRAMEBUF.C
 *
 *	Basic primitive operations for drawing onto a surface backed by a linear
 *  framebuffer.
 *
 *  Copyright (c) 2025 by Will Klees
 */

#include "SURFACE.H"
#include <string.h>
#include "MATH3D.H"

extern u8* backBuffer;

void fb_FillScreen(u8 color) {
    u8* fbptr = backBuffer;
    int i;

    for (i = 0; i < RenderTarget.Height; i++) {
        memset(fbptr, color, RenderTarget.Width);
        fbptr += RenderTarget.Pitch;
    }
}

void fb_PlotPixel(u16 x, u16 y, u8 color) {
    if (x < RenderTarget.Width && y < RenderTarget.Height) {
        backBuffer[y * RenderTarget.Pitch + x] = color;
    }
}

#define sgn(x) ((x<0)?-1:((x>0)?1:0)) /* macro to return the sign of a number */

void fb_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2, u8 color) {
    u16 i, dxabs, dyabs, x, y, px, py, in_range;
    s16 sdx, sdy, dx, dy, y_inc;
    u8* address;

    dx = x2 - x1;	/* the horizontal distance of the line */
    dy = y2 - y1;	/* the vertical distance of the line */

    dxabs = abs(dx);	/* make sure to treat dx as signed */
    dyabs = abs(dy);	/* make sure to treat dy as signed */

    sdx = sgn(dx);	/* see above */
    sdy = sgn(dy);	/* see above */

    y_inc = sdy * RenderTarget.Pitch;

    x = dyabs >> 1;
    y = dxabs >> 1;
	
    px = x1;		/* we'll start the current pixel at (x1, y1) */
    py = y1;

    in_range = 0;

    address = backBuffer + (s16)RenderTarget.Pitch * (s16)py + (s16)px;

    if (py < RenderTarget.Height && px < RenderTarget.Width) { /* plot the first pixel if it's onscreen */
        *address = color;
        in_range = 1;
    }

    if (dxabs >= dyabs) { /* the line is more horizontal than vertical */
        for (i = 0; i < dxabs; i++) {
            y += dyabs;

            if (y >= dxabs) {
                y -= dxabs;
                py += sdy;
                address += y_inc;
            }

            px += sdx;
            address += sdx;

            if (py < RenderTarget.Height && px < RenderTarget.Width) {
                in_range = 1;
            } else if (in_range) { /* if we were in range but went out */
                return;		   /* then we're done */
            }

            if (in_range) *address = color;
        }
    } else { /* the line is more vertical than horizontal */
        for (i = 0; i < dyabs; i++) {
            x += dxabs;

            if (x >= dyabs){
                x -= dyabs;
                px += sdx;
                address += sdx;
            }

            py += sdy;
            address += y_inc;

            if (py < RenderTarget.Height && px < RenderTarget.Width) {
                in_range = 1;
            } else if (in_range) {
                return;
            }

            if (in_range) *address = color;
        }
    }
}


#define int32_t s32

u8 clridx;

typedef struct g3d_vertex {
    s32 x, y;
} g3d_vertex_t;
static void filltop(struct g3d_vertex *v0, struct g3d_vertex *v1, struct g3d_vertex *v2);
static void fillbot(struct g3d_vertex *v0, struct g3d_vertex *v1, struct g3d_vertex *v2);
#define XRES (RenderTarget.Width)
#define YRES (RenderTarget.Height)

void fillspan(u8* dest, int x, int len) {
    memset(dest+x, clridx, len);
}

void g3d_polyfill(struct g3d_vertex *verts)
{
	int i, topidx, botidx, mididx;
	int32_t dx, dy, dym;
	int32_t v01x, v01y, v02x, v02y;
	struct g3d_vertex vtmp;

	/* calculate winding */
	v01x = verts[1].x - verts[0].x;
	v01y = verts[1].y - verts[0].y;
	v02x = verts[2].x - verts[0].x;
	v02y = verts[2].y - verts[0].y;
	if(!((v01x * v02y - v02x * v01y) & 0x80000000)) {
		return;
	}

	topidx = botidx = 0;
	for(i=1; i<3; i++) {
		if(verts[i].y < verts[topidx].y) {
			topidx = i;
		}
		if(verts[i].y > verts[botidx].y) {
			botidx = i;
		}
	}
	mididx = topidx + 1; if(mididx > 2) mididx = 0;
	if(mididx == botidx) {
		if(++mididx > 2) mididx = 0;
	}

	dy = verts[botidx].y - verts[topidx].y;
	if(dy == 0) {
        return;
    }

	dx = verts[botidx].x - verts[topidx].x;
	dym = verts[mididx].y - verts[topidx].y;
	vtmp.x = muldiv(dx, dym, dy) + verts[topidx].x;	/* dx * dym / dy + vtop.x */
	vtmp.y = verts[mididx].y;

	if(verts[topidx].y != verts[mididx].y) {
		filltop(verts + topidx, verts + mididx, &vtmp);
	}
	if(verts[mididx].y != verts[botidx].y) {
		fillbot(verts + mididx, &vtmp, verts + botidx);
	}
}

static void filltop(struct g3d_vertex *v0, struct g3d_vertex *v1, struct g3d_vertex *v2)
{
	struct g3d_vertex *vtmp;
	int x, line, lasty, len;
	int32_t xl, xr, dxl, dxr, slopel, sloper, dy;
	int32_t y0, y1, yoffs;
	unsigned char *fbptr;

	if(v1->x > v2->x) {
		vtmp = v1;
		v1 = v2;
		v2 = vtmp;
	}

	dy = v1->y - v0->y;
	dxl = v1->x - v0->x;
	dxr = v2->x - v0->x;
	slopel = (dxl << 8) / dy;
	sloper = (dxr << 8) / dy;

	y0 = (v0->y + 0x100) & 0xffffff00;	/* start from the next scanline */
	yoffs = y0 - v0->y;					/* offset of the next scanline */
	xl = v0->x + ((yoffs * slopel) >> 8);
	xr = v0->x + ((yoffs * sloper) >> 8);

	line = y0 >> 8;
	lasty = v1->y >> 8;
	if(lasty >= YRES) lasty = YRES - 1;
	x = xl >> 8;

	fbptr = backBuffer + line * (XRES);// >> 2);

	while(line <= lasty) {
		if(line >= 0) {
			len = ((xr + 0x100) >> 8) - (xl >> 8);
			if(len > 0) fillspan(fbptr, x, len);
		}

		xl += slopel;
		xr += sloper;
		x = xl >> 8;
		fbptr += XRES;
		line++;
	}
}

static void fillbot(struct g3d_vertex *v0, struct g3d_vertex *v1, struct g3d_vertex *v2)
{
	struct g3d_vertex *vtmp;
	int x, line, lasty, len;
	int32_t xl, xr, dxl, dxr, slopel, sloper, dy;
	int32_t y0, y1, yoffs;
	unsigned char *fbptr;

	if(v0->x > v1->x) {
		vtmp = v0;
		v0 = v1;
		v1 = vtmp;
	}

	dy = v2->y - v0->y;
	dxl = v2->x - v0->x;
	dxr = v2->x - v1->x;
	slopel = (dxl << 8) / dy;
	sloper = (dxr << 8) / dy;

	y0 = (v0->y + 0x100) & 0xffffff00;	/* start from the next scanline */
	yoffs = y0 - v0->y;					/* offset of the next scanline */
	xl = v0->x + ((yoffs * slopel) >> 8);
	xr = v1->x + ((yoffs * sloper) >> 8);

	line = y0 >> 8;
	lasty = v2->y >> 8;
	if(lasty >= YRES) lasty = YRES - 1;
	x = xl >> 8;

	fbptr = backBuffer + line * (XRES);

	while(line <= lasty) {
		if(line >= 0) {
			len = ((xr + 0x100) >> 8) - (xl >> 8);
			if(len > 0) fillspan(fbptr, x, len);
		}

		xl += slopel;
		xr += sloper;
		x = xl >> 8;
		fbptr += XRES;
		line++;
	}
}

void fb_FillTri(s16 x1, s16 y1, s16 x2, s16 y2, s16 x3, s16 y3, u8 color) {
    g3d_vertex_t verts[3];
    //return;
    clridx = color;

    verts[0].x = 256*x1;
    verts[0].y = 256*y1;
    verts[1].x = 256*x2;
    verts[1].y = 256*y2;
    verts[2].x = 256*x3;
    verts[2].y = 256*y3;

    g3d_polyfill(verts);
    
    //RT_DrawLine(x1, y1, x2, y2, color);
    //RT_DrawLine(x1, y1, x3, y3, color);
    //RT_DrawLine(x3, y3, x2, y2, color);
}

