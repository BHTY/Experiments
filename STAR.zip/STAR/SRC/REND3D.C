/*
 *	File: REND3D.C
 *
 *	Basic functions for 3D rendering.
 *
 *	Copyright (c) 2025 by Will Klees
 */

#include "REND3D.H"
#include "SURFACE.H"
#include <string.h>
#include <math.h>
#include <conio.h>

/* Important constants */
#define GFX_MAX_VERTS 1000
#define GFX_MAX_POLYS 1000
#define GFX_Z_LEVELS  512

/* Important state variables */
u32         gfxVertexIndex;
u32         gfxPolygonIndex;
TRANSFORM   gfxModelView;
GFX_VERT    gfxVertexBuffer[GFX_MAX_VERTS];
GFX_Z_BIN   gfxPolygonBuffer[GFX_MAX_POLYS];
GFX_Z_BIN*  gfxZBin[GFX_Z_LEVELS];
FIXED       gfxNearClip;
FIXED       gfxFarClip;
int         gfxDrawMode = GFX_FILL;
s16         gfxViewportHalfHeight;
s16         gfxViewportHalfWidth;

/* Lights */
VEC3 lightdir = {0, 0*ITOFIX(1), 1*ITOFIX(1)};

/* Clears geometry buffers */
void gfx_clear() {
    gfxVertexIndex = 0;
    gfxPolygonIndex = 0;
    memset(gfxZBin, 0, sizeof(gfxZBin));
}

/* Actually draws a polygon onto the screen */
void gfx_draw_poly(GFX_Z_BIN* entry) {
    if (gfxDrawMode == GFX_FILL) {
        RT_FillTri(entry->v0->ssx, entry->v0->ssy, entry->v1->ssx, entry->v1->ssy, entry->v2->ssx, entry->v2->ssy, entry->color);
    } else if (gfxDrawMode == GFX_WIRE) {    
        RT_DrawLine(entry->v0->ssx, entry->v0->ssy, entry->v1->ssx, entry->v1->ssy, entry->color);
        RT_DrawLine(entry->v0->ssx, entry->v0->ssy, entry->v2->ssx, entry->v2->ssy, entry->color);
        RT_DrawLine(entry->v2->ssx, entry->v2->ssy, entry->v1->ssx, entry->v1->ssy, entry->color);
    }
}

/* Display all onscreen polygons */
void gfx_present() {
    int i;

    /* Draw each Z bin from back to front */
    for (i = GFX_Z_LEVELS-1; i >= 0; i--) {
        GFX_Z_BIN* entry = gfxZBin[i];

        while (entry) {
            gfx_draw_poly(entry);
            entry = entry->next;
        }
    }
}

/* Returns 1 if the vertex is within the clipping region, and if so, converts it to a small vertex */
int  gfx_clip(VEC3* v) {
    if (v->z >= gfxNearClip && v->z <= gfxFarClip) {
        return 1;
    }

    return 0;
}

/* */
int  gfx_xform(VEC3* v, GFX_VERT* iv) {
    VEC3 vr;
    GFX_MV_XFORM(v, &(iv->vs));
    if (gfx_clip(&(iv->vs))) {
        iv->ssx = gfxViewportHalfWidth  + muldiv(iv->vs.x, gfxViewportHalfWidth, iv->vs.z);
        iv->ssy = gfxViewportHalfHeight + muldiv(iv->vs.y, gfxViewportHalfHeight, iv->vs.z);
        //printf("%08X %08X\n", iv->ssx, iv->ssy);
        //printf("%08X %08X %08X\n", iv->vs.x, gfxViewportHalfWidth, iv->vs.z);
        //getch();
        return 1;
    } else {
        iv->vs.z = 0;
        return 0;
    }
}

/* */
void gfx_vertex(VEC3* v) {
    gfx_xform(v, &(gfxVertexBuffer[gfxVertexIndex++]));
}

/* Sets clipping parameters */
void gfx_zclip(FIXED clipNear, FIXED clipFar) {
    gfxNearClip = clipNear;
    gfxFarClip = clipFar;
}

/* */
void gfx_submit_tri(u16 i0, u16 i1, u16 i2, u8 color) {
    GFX_Z_BIN* entry = &(gfxPolygonBuffer[gfxPolygonIndex]);
    FIXED z, z1, z2, z3;
    int bin_index;

    entry->v0 = &(gfxVertexBuffer[i0]);
    entry->v1 = &(gfxVertexBuffer[i1]);
    entry->v2 = &(gfxVertexBuffer[i2]);

    z1 = entry->v0->vs.z;
    z2 = entry->v1->vs.z;
    z3 = entry->v2->vs.z;

    if (z1 == 0 || z2 == 0 || z3 == 0) return;

    z = (z1 + z2 + z3) / 3;
    bin_index = FIXTOI(z);

    if ((u16)bin_index < GFX_Z_LEVELS) { /* Add to bin */
        if (gfxDrawMode == GFX_FILL) {
            VEC3 e1 = entry->v1->vs;
            VEC3 e2 = entry->v2->vs;
            VEC3 norm;
            FIXED mag;
            FIXED level;

            vec3_sub(&(entry->v0->vs), &e1);
            vec3_sub(&(entry->v0->vs), &e2);

            vec3_cross(&e1, &e2, &norm);

            if (norm.z >= 0) return; /* Back face culling */

            mag = vec3_mag(&norm);
            level = -fixed_div(vec3_dot(&norm, &lightdir), mag);
            
            if (level < 0) level = 0;
            if (level > 0x10000) level = 0x10000;

            //level = 0x10000;
            
            entry->color = (color << 4) | ((FIXTOI(level*15))&15);
/*
            printf("norm %f %f %f\n", FIXTOF(norm.x), FIXTOF(norm.y), FIXTOF(norm.z));
            printf("lght %f %f %f\n", FIXTOF(lightdir.x), FIXTOF(lightdir.y), FIXTOF(lightdir.z));
            printf("mag %f\n", FIXTOF(mag));
            printf("dot %f\n", FIXTOF(vec3_dot(&norm, &lightdir)));
            printf("level %f\n", FIXTOF(level));
            getch();*/

        } else if (gfxDrawMode == GFX_WIRE) {
            entry->color = (color << 4) | 15;
        }
    
        entry->next = gfxZBin[bin_index];
        gfxZBin[bin_index] = entry;
        gfxPolygonIndex++;
    }
}

/* */
void    gfx_viewport(u16 x, u16 y) {
    gfxViewportHalfHeight = y / 2;
    gfxViewportHalfWidth = x / 2;
}

/* */
void    gfx_drawmode(int mode) {
    gfxDrawMode = mode;
}

