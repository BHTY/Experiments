/*
 *	File: VMATH.C
 *
 *	Basic vector and matrix math routines.
 *
 *	Copyright (c) 2025 by Will Klees
 */

#define USE_INT64
#include "MATH3D.H"
#include <math.h>

#define MAT3_DOT(a, b, row, col)    (fixed_mul((a)[row][0], (b)[0][col]) + fixed_mul((a)[row][1], (b)[1][col]) + fixed_mul((a)[row][2], (b)[2][col]))
#define XFORM_DOTV(a, row, v)       (fixed_mul((v).x, (a)->rot[row][0]) + fixed_mul((v).y, (a)->rot[row][1]) + fixed_mul((v).z, (a)->rot[row][2]))

FIXED   fixed_mul(FIXED a, FIXED b) {
    s64 product = (s64)a * (s64)b;
    return product >> FP_SHIFT;
}

FIXED   fixed_div(FIXED a, FIXED b) {
    return (s64)(((s64)a) << FP_SHIFT) / b;
}

FIXED   muldiv(FIXED a, FIXED b, FIXED c) {
    return (s64)a * (s64)b / c;
}

void    vec3_add(VEC3* a, VEC3* b) {
    b->x += a->x;
    b->y += a->y;
    b->z += a->z;
}

void    vec3_sub(VEC3* a, VEC3* b) {
    b->x -= a->x;
    b->y -= a->y;
    b->z -= a->z;
}

void    vec3_scale(VEC3* v, FIXED scale, VEC3* vo) {
    vo->x = fixed_mul(v->x, scale);
    vo->y = fixed_mul(v->y, scale);
    vo->z = fixed_mul(v->z, scale);
}

void    vec3_cross(VEC3* a, VEC3* b, VEC3* o) {
    FIXED x = fixed_mul(a->y, b->z) - fixed_mul(a->z, b->y);
    FIXED y = fixed_mul(a->z, b->x) - fixed_mul(a->x, b->z);
    FIXED z = fixed_mul(a->x, b->y) - fixed_mul(a->y, b->x);

    o->x = x;
    o->y = y;
    o->z = z;
}

FIXED   vec3_dot(VEC3* a, VEC3* b) {
    return fixed_mul(a->x, b->x) + fixed_mul(a->y, b->y) + fixed_mul(a->z, b->z);
}

FIXED   vec3_mag(VEC3* v) {
    float xf = FIXTOF(v->x);
    float yf = FIXTOF(v->y);
    float zf = FIXTOF(v->z);

    return FTOFIX(sqrt(xf*xf + yf*yf + zf*zf));
}

void    mat3_mul(FIXED a[3][3], FIXED b[3][3], FIXED m[3][3]) {
    m[0][0] = MAT3_DOT(a, b, 0, 0);
    m[0][1] = MAT3_DOT(a, b, 0, 1);
    m[0][2] = MAT3_DOT(a, b, 0, 2);
    
    m[1][0] = MAT3_DOT(a, b, 1, 0);
    m[1][1] = MAT3_DOT(a, b, 1, 1);
    m[1][2] = MAT3_DOT(a, b, 1, 2);
    
    m[2][0] = MAT3_DOT(a, b, 2, 0);
    m[2][1] = MAT3_DOT(a, b, 2, 1);
    m[2][2] = MAT3_DOT(a, b, 2, 2);
}

void    mat3_mulv(FIXED m[3][3], VEC3* v, VEC3* r) {
    FIXED x = vec3_dot((VEC3*)(m[0]), v);
    FIXED y = vec3_dot((VEC3*)(m[1]), v);
    FIXED z = vec3_dot((VEC3*)(m[2]), v);

    r->x = x;
    r->y = y;
    r->z = z;
}

void    xform_mul(TRANSFORM* a, TRANSFORM* b, TRANSFORM* r) {
    mat3_mul(a->rot, b->rot, r->rot);
    r->trans.x = XFORM_DOTV(a, 0, b->trans) + a->trans.x;
    r->trans.y = XFORM_DOTV(a, 1, b->trans) + a->trans.y;
    r->trans.z = XFORM_DOTV(a, 2, b->trans) + a->trans.z;
}

void    xform_mulv(TRANSFORM* t, VEC3* vi, VEC3* vo) {
    VEC3 v;
    mat3_mulv(t->rot, vi, &v);

    vo->x = v.x + t->trans.x;
    vo->y = v.y + t->trans.y;
    vo->z = v.z + t->trans.z;
}
