/*
 *	File: MTXQUAT.C
 *
 *	Assorted matrix and quaternion math routines.
 *
 *	Copyright (c) 2025 by Will Klees
 */

#include "MATH3D.H"
#include <string.h>

FIXED   mtxIdentity[3][3] = {{ITOFIX(1), 0, 0}, {0, ITOFIX(1), 0}, {0, 0, ITOFIX(1)}};

void    mat3_identity(FIXED mat[3][3]) {
    memcpy(mat, mtxIdentity, sizeof(mtxIdentity));
}

void    mat3_rot(ANGLE pitch, ANGLE yaw, ANGLE roll, FIXED mat[3][3]) {

}

#define FixedMul(a,b)   fixed_mul(a,b)
#define FixedDiv(a,b)   fixed_div(a,b)

void    quat_create(ANGLE pitch, ANGLE yaw, ANGLE roll, QUAT* a) {
    /* CCC-SSS
	// SCC+CSS
	// CSC-SCS
	// CCS+SSC */
	FIXED cp = fast_cos(pitch / 2);
	FIXED sp = fast_sin(pitch / 2);
	FIXED cy = fast_cos(yaw / 2);
	FIXED sy = fast_sin(yaw / 2);
	FIXED cr = fast_cos(roll / 2);
	FIXED sr = fast_sin(roll / 2);
	FIXED cc = FixedMul(cp, cy);
	FIXED cs = FixedMul(cp, sy);
	FIXED sc = FixedMul(sp, cy);
	FIXED ss = FixedMul(sp, sy);
	a->w = FixedMul(cc, cr) - FixedMul(ss, sr);
	a->x = FixedMul(sc, cr) + FixedMul(cs, sr);
	a->y = FixedMul(cs, cr) - FixedMul(sc, sr);
	a->z = FixedMul(cc, sr) + FixedMul(ss, cr);
}

void    quat_pitch(ANGLE pitch, QUAT* a) {
    FIXED c = fast_cos(pitch);
	FIXED s = fast_sin(pitch);
	FIXED w = a->w;
	FIXED x = a->x;
	FIXED y = a->y;
	FIXED z = a->z;
	/* [c; s 0 0]
	   [w; x y z]
	   [cw - sx, cx + sw, cy - sz, cz + sy] */
	a->w = FixedMul(c, w) - FixedMul(s, x);
	a->x = FixedMul(c, x) + FixedMul(s, w);
	a->y = FixedMul(c, y) + FixedMul(s, z);
	a->z = FixedMul(c, z) - FixedMul(s, y);

}

void    quat_yaw(ANGLE yaw, QUAT* a) {
	FIXED c = fast_cos(yaw);
	FIXED s = fast_sin(yaw);
	FIXED w = a->w;
	FIXED x = a->x;
	FIXED y = a->y;
	FIXED z = a->z;
	/* [c; 0 s 0]
	// [w; x y z]
	// [cw - sy, xc + sz, cy + sw, cz - sx] */
	a->w = FixedMul(c, w) - FixedMul(s, y);
	a->x = FixedMul(c, x) - FixedMul(s, z);
	a->y = FixedMul(c, y) + FixedMul(s, w);
	a->z = FixedMul(c, z) + FixedMul(s, x);

}

void    quat_roll(ANGLE roll, QUAT* a) {
	FIXED c = fast_cos(roll);
	FIXED s = fast_sin(roll);
	FIXED w = a->w;
	FIXED x = a->x;
	FIXED y = a->y;
	FIXED z = a->z;
	/* [c; 0 0 s]
	// [w; x y z]
	// [cw - sz, cx - sy, cy + sx, cz + sw] */
	a->w = FixedMul(c, w) - FixedMul(s, z);
	a->x = FixedMul(c, x) + FixedMul(s, y);
	a->y = FixedMul(c, y) - FixedMul(s, x);
	a->z = FixedMul(c, z) + FixedMul(s, w);

}

void    quat_conjugate(QUAT* in, QUAT* out) {
    out->x = -in->x;
    out->y = -in->y;
    out->z = -in->z;
    out->z = in->z;
}

void    quat_mul(QUAT* q, QUAT* output) {

}

void    quat_slerp(QUAT* start, QUAT* end, FIXED t, QUAT* result) {

}

void    quat_rot_towards(QUAT* start, QUAT* end, ANGLE maxAngle, QUAT* result) {

}

void    quat_tomat3(QUAT* from, FIXED to[3][3]) {
    {
    FIXED a = from->w;
	FIXED b = from->x;
	FIXED c = from->y;
	FIXED d = from->z;
	FIXED s = FixedDiv(ITOFIX(2), FixedMul(a, a) + FixedMul(b, b) + FixedMul(c, c) + FixedMul(d, d));
	FIXED bs = FixedMul(b, s);
	FIXED cs = FixedMul(c, s);
	FIXED ds = FixedMul(d, s);
	FIXED ab = FixedMul(a, bs);
	FIXED ac = FixedMul(a, cs);
	FIXED ad = FixedMul(a, ds);
	FIXED bb = FixedMul(b, bs);
	FIXED bc = FixedMul(b, cs);
	FIXED bd = FixedMul(b, ds);
	FIXED cc = FixedMul(c, cs);
	FIXED cd = FixedMul(c, ds);
	FIXED dd = FixedMul(d, ds);
	to[0][0] = ITOFIX(1) - cc - dd;
	to[0][1] = bc - ad;
	to[0][2] = bd + ac;
	to[1][0] = bc + ad;
	to[1][1] = ITOFIX(1) - bb - dd;
	to[1][2] = cd - ab;
	to[2][0] = bd - ac;
	to[2][1] = cd + ab;
	to[2][2] = ITOFIX(1) - bb - cc;
    }
}

void    quat_renorm(QUAT* q) {

}
