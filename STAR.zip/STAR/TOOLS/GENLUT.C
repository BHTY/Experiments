/* Quick and dirty program to generate trig lut */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#define STEPS 4096
#define M_PI 3.14159265358979323846
#define FIXED_TYPE signed long
#define FIXED_SHIFT 16
char* typename = "FIXED";

int main(int argc, char** argv) {
    FILE* fp;
    int i;

    if (argc != 2) {
        fprintf(stderr, "Usage: %s destfile\n", argv[0]);
        return -1;
    }

    fp = fopen(argv[1], "w");

    if (!fp) {
        fprintf(stderr, "Failed to open output file for writing: error %d\n", errno);
        return -1;
    }

    fprintf(fp, "#include \"MATH3D.H\"\n");
    fprintf(fp, "%s SIN_LUT[%d] = {", typename, STEPS);

    for (i = 0; i < STEPS; i++) {
        double r = sin(2 * M_PI * i / STEPS);
        FIXED_TYPE c = r * (1L<<FIXED_SHIFT);
        fprintf(fp, "\t(%s)0x%lx,\n", typename, c);
    }

    fprintf(fp, "};\n");
    
    fclose(fp);

    return 0;
}
