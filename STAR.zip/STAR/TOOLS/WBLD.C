/* Quick and dirty program to read in a file containing a space-delimited list of objects, and use that in conjunction with other command-line args to generate and invoke a Watcom linker script */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int main(int argc, char** argv) {
    int i;
    int minimumArgumentsProcessed = 0;
    char* objList;
    char* outputName;
    char* systemType;
    FILE* fpLinkerScript;
    FILE* fpObjectList;

    fpLinkerScript = fopen("temp.lnk", "w");

    if (!fpLinkerScript) {
        fprintf(stderr, "Failed to open temporary output file for writing: error %d\n", errno);
        return -1;
    }

    for (i = 1; i < argc; i++) {
        if (i == 1) { /* Object list */
            objList = argv[i];
        } else if (i == 2) { /* Output name */
            outputName = argv[i];
        } else if (i == 3) { /* System type */
            systemType = argv[i];
            minimumArgumentsProcessed = 1;
        }
    }

    if (!minimumArgumentsProcessed) {
        printf("Usage: WBLD objlist output_name system_type [options]\n");
        return -1;
    }

    fpObjectList = fopen(objList, "r+");

    if (!fpObjectList) {
        fprintf(stderr, "Failed to open file containing object list for reading: error %d\n", errno);
    }

    /* Process options */
    for (i = 4; i < argc; i++) {
        if (strcmp(argv[i], "DEBUG") == 0) {
            if (argc > i+1) { /* Debug argument */
                fprintf(fpLinkerScript, "DEBUG %s ", argv[i+1]);
                i++;

                if (argc > i+1) { /* More debug args */
                    if (memcmp(argv[i+1], "LINES", 5) == 0 || memcmp(argv[i+1], "TYPES", 5) == 0 || memcmp(argv[i+1], "LOCALS", 6) == 0 || strcmp(argv[i+1], "ALL") == 0) {
                        fprintf(fpLinkerScript, "%s", argv[i+1]);
                        i++;
                    }
                }

                fprintf(fpLinkerScript, "\n");
            } else {
                fprintf(stderr, "DEBUG option needs to be followed by argument\n");
                return -1;
            }
        } else {
            fprintf(fpLinkerScript, "OPTION %s\n", argv[i]);
        }
    }

    /* Output required fields */
    fprintf(fpLinkerScript, "NAME %s\n", outputName);
    fprintf(fpLinkerScript, "SYSTEM %s\n", systemType);

    /* Read each object from the object list */
    {
        char objName[128];

        while (fscanf(fpObjectList, "%s ", objName) == 1) {
            fprintf(fpLinkerScript, "FILE %s\n", objName);
        }
    }

    /* Close all files */
    fclose(fpLinkerScript);
    fclose(fpObjectList);

    /* Invoke the linker */
    system("wlink @temp.lnk");
    system("del temp.lnk");
    
    return 0;
}
